import CalculatorContainer from "./components/Calculator/CalculatorContainer";

export default function Home() {
  return (
    <div className="w-full">
      <CalculatorContainer />
    </div>
  );
}
