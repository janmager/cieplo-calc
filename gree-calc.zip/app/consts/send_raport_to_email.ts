export const send_raport_to_email: any = [
    {
        name: 'Chcę wysłać link z wynikiem na maila'
    },
    {
        name: 'Nie, dziękuję.'
    },
]