export const send_raport_accept_24h: any = [
    {
        name: 'Tak, poproszę o kontakt'
    },
    {
        name: 'Nie, dziękuję.'
    },
]