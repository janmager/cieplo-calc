export const building_types: any = [
    {
        name: 'Dom jednorodzinny'
    },
    {
        name: 'Bliźniak (połowa budynku)'
    },
    {
        name: 'Segment w zabudowanie szeregowej'
    },
    {
        name: 'Mieszkanie'
    },
    {
        name: 'Budynek wielorodzinny'
    },
]