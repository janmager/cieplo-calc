export const building_construction_type: any = [
    {
        name: 'Tradycyjna - murowana lub z drewna'
    },
    {
        name: 'Szkieletowa - dom kanadyjski'
    },
]