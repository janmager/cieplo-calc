export const windows_type: any = [
    {
        name: 'Starsze z pojedynczą zwykłą szybą',
        value: 'Starsze z pojedynczą zwykłą szybą'
    },
    {
        name: 'Starsze z min. dwiema zwykłymi szybami',
        value: 'Starsze z min. dwiema zwykłymi szybami',
    },
    {
        name: 'Starsze z szybami zespolonymi',
        value: 'Starsze z szybami zespolonymi',
    },
    {
        name: '2011-2020 dwuszybowe',
        value: '2011-2020 dwuszybowe',
    },
    {
        name: '2011-2020 trójszybowe',
        value: '2011-2020 trójszybowe',
    },
    {
        name: '2021+ dwuszybowe',
        value: '2021+ dwuszybowe',
    },
    {
        name: '2021+ trójszybowe',
        value: '2021+ trójszybowe',
    },
]