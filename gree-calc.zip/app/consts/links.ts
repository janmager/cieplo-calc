export const links = {
    host: process.env.NEXT_PUBLIC_HOST
}