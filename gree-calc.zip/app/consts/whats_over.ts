export const whats_over: any = [
    {
        name: 'Ogrzewany lokal',
        value: 'Ogrzewany lokal', 
    },
    {
        name: 'Nieogrzewany lokal',
        value: 'Nieogrzewany lokal',
    },
    {
        name: 'Świat zewnętrzny',
        value: 'Świat zewnętrzny',
    },
]