export const building_outline_sizes: any = [
    {
        name: 'Znam wymiary zewnętrzne budynku'
    },
    {
        name: 'Znam powierzchnię zabudowy'
    },
]