export const mieszkanie_size: any = [
    {
        name: 'Jednopoziomowe',
        value: 'Jednopoziomowe'
    },
    {
        name: 'Dwupoziomowe',
        value: 'Dwupoziomowe'
    },
    {
        name: 'Trzypoziomowe',
        value: 'Trzypoziomowe'
    },
]