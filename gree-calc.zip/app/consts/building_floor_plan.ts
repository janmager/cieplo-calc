export const building_floor_plan: any = [
    {
        name: 'Parterowy',
        value: 'Parterowy'
    },
    {
        name: 'Jednopiętrowy',
        value: 'Jednopiętrowy',
    },
    {
        name: 'Dwupiętrowy',
        value: 'Dwupiętrowy',
    },
    {
        name: 'Trzypiętrowy',
        value: 'Trzypiętrowy',
    },
    {
        name: 'Czteropiętrowy',
        value: 'Czteropiętrowy',
    },
]

export const building_floor_plan_wielorodzinny: any = [
    {
        name: 'Jednopiętrowy',
        value: 'Jednopiętrowy',
    },
    {
        name: 'Dwupiętrowy',
        value: 'Dwupiętrowy',
    },
    {
        name: 'Trzypiętrowy',
        value: 'Trzypiętrowy',
    },
    {
        name: 'Czteropiętrowy',
        value: 'Czteropiętrowy',
    },
    {
        name: "Pięcopiętrowy",
        value: "Pięciopiętrowy"
    },
    {
        name: "Sześciopiętrowy",
        value: "Sześciopiętrowy"
    },
    {
        name: "Siedmiopiętrowy",
        value: "Siedmiopiętrowy"
    },
    {
        name: "Ośmiopiętrowy",
        value: "Ośmiopiętrowy"
    },
    {
        name: "Dziewięciopiętrowy",
        value: "Dziewięciopiętrowy"
    },
    {
        name: "Dziesięciopiętrowy",
        value: "Dziesięciopiętrowy"
    },
    {
        name: "Jedenastopiętrowy",
        value: "Jedenastopiętrowy"
    },
    {
        name: "Dwunastopiętrowy",
        value: "Dwunastopiętrowy"
    },
]