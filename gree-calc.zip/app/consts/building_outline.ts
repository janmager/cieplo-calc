export const building_outline: any = [
    {
        name: 'Regularny – prostokątny'
    },
    {
        name: 'Nieregularny (wszelkie inne kształty)'
    },
]