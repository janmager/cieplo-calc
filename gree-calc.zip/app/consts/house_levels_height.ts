export const house_levels_height: any = [
    {
        name: 'Niskie (poniżej 2,5m)',
        value: 'Niskie (poniżej 2,5m)'
    },
    {
        name: 'Standardowe (ok. 2,6m)',
        value: 'Standardowe (ok. 2,6m)'
    },
    {
        name: 'Wysokie (ok. 3m)',
        value: 'Wysokie (ok. 3m)'
    },
    {
        name: 'Bardzo wysokie (4m i więcej)',
        value: 'Bardzo wysokie (4m i więcej)'
    },
]