export const house_building_years: any = [
    {
        name: '2025',
        value: '2025', 
    },
    {
        name: '2024',
        value: '2024', 
    },
    {
        name: '2023',
        value: '2023', 
    },
    {
        name: '2022',
        value: '2022', 
    },
    {
        name: '2021',
        value: '2021', 
    },
    {
        name: '2020',
        value: '2020', 
    },
    {
        name: '2010-2019',
        value: '2010-2019', 
    },
    {
        name: '2000-2009',
        value: '2000-2009', 
    },
    {
        name: '1990-1999',
        value: '1990-1999', 
    },
    {
        name: '1980-1989',
        value: '1980-1989', 
    },
    {
        name: '1970-1979',
        value: '1970-1979', 
    },
    {
        name: 'starsze',
        value: 'starsze', 
    },
]