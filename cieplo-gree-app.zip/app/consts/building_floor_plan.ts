export const building_floor_plan: any = [
    {
        name: 'Parterowy',
        value: 'Parterowy'
    },
    {
        name: 'Jednopiętrowy',
        value: 'Jednopiętrowy',
    },
    {
        name: 'Dwupiętrowy',
        value: 'Dwupiętrowy',
    },
    {
        name: 'Trzypiętrowy',
        value: 'Trzypiętrowy',
    },
    {
        name: 'Czteropiętrowy',
        value: 'Czteropiętrowy',
    },
]