export const whats_under: any = [
    {
        name: 'Ogrzewany lokal',
        value: 'Ogrzewany lokal', 
    },
    {
        name: 'Nieogrzewany lokal',
        value: 'Nieogrzewany lokal',
    },
    {
        name: 'Świat zewnętrzny',
        value: 'Świat zewnętrzny',
    },
    {
        name: 'Grunt',
        value: 'Grunt'
    }
]