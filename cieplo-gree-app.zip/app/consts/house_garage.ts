export const house_garage: any = [
    {
        name: 'Brak',
        value: 'Brak'
    },
    {
        name: 'Jednostanowiskowy nieogrzewany',
        value: 'Jednostanowiskowy nieogrzewany'
    },
    {
        name: 'Jednostanowiskowy (d)ogrzewany',
        value: 'Jednostanowiskowy (d)ogrzewany'
    },
    {
        name: 'Dwustanowiskowy nieogrzewany',
        value: 'Dwustanowiskowy nieogrzewany'
    },
    {
        name: 'Dwustanowiskowy (d)ogrzewany',
        value: 'Dwustanowiskowy (d)ogrzewany'
    },
]