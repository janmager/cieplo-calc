export const max_temp_of_power_instalation: any = [
    // {
    //     name: 'Nie wiem',
    //     value: 'Nie wiem'
    // },
    {
        name: '25 °C',
        value: '25 °C',
    },
    {
        name: '30 °C',
        value: '30 °C',
    },
    {
        name: '35 °C',
        value: '35 °C',
    },
    {
        name: '40 °C',
        value: '40 °C',
    },
    {
        name: '45 °C',
        value: '45 °C',
    },
    {
        name: '50 °C',
        value: '50 °C',
    },
]