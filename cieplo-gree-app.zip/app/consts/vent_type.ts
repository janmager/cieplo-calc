export const vent_type: any = [
    {
        name: 'Naturalna lub grawitacyjna',
        value: 'Naturalna lub grawitacyjna', 
    },
    {
        name: 'Mechaniczna',
        value: 'Mechaniczna',
    },
    {
        name: 'Mechaniczna z odzyskiem ciepła',
        value: 'Mechaniczna z odzyskiem ciepła',
    },
]