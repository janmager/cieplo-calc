export const doors_type: any = [
    {
        name: 'Nowe drewniane',
        value: 'Nowe drewniane'
    },
    {
        name: 'Stare drewniane',
        value: 'Stare drewniane'
    },
    {
        name: 'Nowe metalowe',
        value: 'Nowe metalowe'
    },
    {
        name: 'Stare metalowe',
        value: 'Stare metalowe'
    },
    {
        name: 'Nowe z tworzywa',
        value: 'Nowe z tworzywa'
    },
]