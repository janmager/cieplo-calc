export const building_roof_plan: any = [
    {
        name: 'Płaski',
        value: 'Płaski'
    },
    {
        name: 'Skośny z poddaszem',
        value: 'Skośny z poddaszem',
    },
    {
        name: 'Skośny bez poddasza',
        value: 'Skośny bez poddasza',
    },
]