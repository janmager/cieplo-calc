export const hot_water_using_style: any = [
    {
        name: 'Tylko prysznice',
        value: 'Tylko prysznice',
    },
    {
        name: 'Głównie przysznice, czasem wanna',
        value: 'Głównie przysznice, czasem wanna'
    },
    {
        name: 'Najczęściej wanna',
        value: 'Najczęściej wanna',
    },
]