export const main_heat_sources: any = [
    {
        name: 'Pompa ciepła powietrze-woda',
        value: 'Pompa ciepła powietrze-woda', 
    },
    // {
    //     name: 'Pompa ciepła powietrze-powietrze (klimatyzacja)',
    //     value: 'Pompa ciepła powietrze-powietrze (klimatyzacja)',
    // },
    // {
    //     name: 'Pompa ciepła gruntowa',
    //     value: 'Pompa ciepła gruntowa',
    // },
    // {
    //     name: 'Kocioł na drewno z buforem ciepła',
    //     value: 'Kocioł na drewno z buforem ciepła',
    // },
    // {
    //     name: 'Kocioł na drewno',
    //     value: 'Kocioł na drewno',
    // },
    // {
    //     name: 'Kocioł na pellet drzewny',
    //     value: 'Kocioł na pellet drzewny',
    // },
    // {
    //     name: 'Kocioł na zrębkę drzewną',
    //     value: 'Kocioł na zrębkę drzewną',
    // },
    // {
    //     name: 'Kocioł gazowy kondensacyjny',
    //     value: 'Kocioł gazowy kondensacyjny',
    // },
    // {
    //     name: 'Kocioł gazowy niekondensacyjny',
    //     value: 'Kocioł gazowy niekondensacyjny',
    // },
    // {
    //     name: 'Kocioł węglowy bez podajnika z buforem ciepła',
    //     value: 'Kocioł węglowy bez podajnika z buforem ciepła',
    // },
    // {
    //     name: 'Kocioł węglowy bez podajnika',
    //     value: 'Kocioł węglowy bez podajnika',
    // },
    // {
    //     name: 'Kocioł węglowy z podajnikiem',
    //     value: 'Kocioł węglowy z podajnikiem',
    // },
    // {
    //     name: 'Prąd: promienniki podczerwieni / maty grzewcze',
    //     value: 'Prąd: promienniki podczerwieni / maty grzewcze',
    // },
    // {
    //     name: 'Prąd: piec akumulacyjny / bufor wodny z grzałkami',
    //     value: 'Prąd: piec akumulacyjny / bufor wodny z grzałkami',
    // },
    // {
    //     name: 'Kocioł olejowy',
    //     value: 'Kocioł olejowy',
    // },
    // {
    //     name: 'Piec (kaflowy, kuchenny, koza itp.)',
    //     value: 'Piec (kaflowy, kuchenny, koza itp.)',
    // },
    // {
    //     name: 'Kominek',
    //     value: 'Kominek',
    // },
    // {
    //     name: 'Sieć ciepłownicza',
    //     value: 'Sieć ciepłownicza',
    // },
]