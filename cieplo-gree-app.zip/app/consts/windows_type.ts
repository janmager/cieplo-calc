export const windows_type: any = [
    {
        name: 'Stare z pojedynczą szybą',
        value: 'Stare z pojedynczą szybą'
    },
    {
        name: 'Stare z min. dwiema szybami',
        value: 'Stare z min. dwiema szybami',
    },
    {
        name: 'Starsze (10+ lat) ale z szybami zespolonymi',
        value: 'Starsze (10+ lat) ale z szybami zespolonymi',
    },
    {
        name: 'Współczesne dwuszybowe',
        value: 'Współczesne dwuszybowe',
    },
    {
        name: 'Współczesne trójszybowe',
        value: 'Współczesne trójszybowe',
    },
]