export const type_of_heating_instalation: any = [
    {
        name: '100% grzejniki',
        value: '100% grzejniki',
    },
    {
        name: 'Przewaga grzejników + nieco podłogowego/ściennego',
        value: 'Przewaga grzejników + nieco podłogowego/ściennego',
    },
    {
        name: 'Mniej więcej po równo grzejników i podłogowego/ściennego',
        value: 'Mniej więcej po równo grzejników i podłogowego/ściennego',
    },
    {
        name: 'Przewaga podłogowego/ściennego + nieco grzejników',
        value: 'Przewaga podłogowego/ściennego + nieco grzejników',
    },
    {
        name: '100% podłogowe / ścienne',
        value: '100% podłogowe / ścienne'
    },
    {
        name: 'Ogrzewanie nadmuchowe',
        value: 'Ogrzewanie nadmuchowe',
    },
    {
        name: 'Brak centralnego ogrzewania',
        value: 'Brak centralnego ogrzewania',
    },
]