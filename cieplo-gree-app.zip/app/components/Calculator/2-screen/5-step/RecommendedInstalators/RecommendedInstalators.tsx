import React from 'react'
import phoneIcon from '@/assets/svg/phone-icon-2.svg'
import postIcon from '@/assets/svg/post-icon.svg'
import Image from 'next/image'
import { Instalators } from '@prisma/client'

function RecommendedInstalators({instalators}: {instalators: Instalators[]}) {
  return (
    <div className='flex flex-col'>
        {
            instalators && instalators.length ? instalators.map((instalator: Instalators, id: number) => (
                <div key={id} className='grid md:grid-cols-3 onPrintHardGrid3 gap-3 md:gap-0 py-[16px] border-b border-[#D9D9D9]'>
                    <div className='text-[18px] onPrintText14 font-[500]'>
                        {instalator.name}
                    </div>
                    <div className='flex flex-row gap-3 items-center md:pl-10'>
                        <Image src={phoneIcon.src} className="pdf-margin-top" height={24} width={18} alt='phone' />
                        <span className='text-[#FF4510] onPrintText14 text-[16px] font-[400]'>{instalator.phone}</span>
                    </div>
                    <div className='flex flex-row gap-3 items-center md:pl-10'>
                        <Image src={postIcon.src} className="pdf-margin-top" height={30} width={24} alt='phone' />
                        <span className='text-[#FF4510] onPrintText14 text-[16px] font-[400]'>{instalator.postalAndCity}</span>
                    </div>
                </div>
            )) : <div className='opacity-50 pb-10'>brak poleceń</div>
        }
    </div>
  )
}

export default RecommendedInstalators