import React from 'react'
import CalculatorContainer from '../components/Calculator/CalculatorContainer'

function page() {
  return (
    <CalculatorContainer />
  )
}

export default page