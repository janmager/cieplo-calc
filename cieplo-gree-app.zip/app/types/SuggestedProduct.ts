export interface SuggestedProduct {
    name: string;
    model: string;
    img: string;
    link: string;
}