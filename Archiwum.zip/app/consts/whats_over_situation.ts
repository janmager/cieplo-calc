export const whats_over_situation: any = [
    {
        name: 'Brak izolacji i odczuwalne są silne przeciągi',
        value: 'Brak izolacji i odczuwalne są silne przeciągi', 
    },
    {
        name: 'Pomieszczenie jest dość szczelne, ale ocieplone słabiej niż mieszkanie',
        value: 'Pomieszczenie jest dość szczelne, ale ocieplone słabiej niż mieszkanie'
    },
    {
        name: 'To pomieszczenie mieszkalne ocieplone nie gorzej jak nasze, tylko chwilowo nikt tam nie mieszka',
        value: 'To pomieszczenie mieszkalne ocieplone nie gorzej jak nasze, tylko chwilowo nikt tam nie mieszka'
    },
]