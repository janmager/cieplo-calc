export const navbar_items = [
    {
        name: 'Produkty',
        href: '#'
    },
    {
        name: 'Rozwiązania',
        href: '#'
    },
    {
        name: 'Wsparcie',
        href: '#'
    },
    {
        name: 'Gree',
        href: '#'
    }
]