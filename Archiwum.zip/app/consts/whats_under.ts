export const whats_under: any = [
    {
        name: 'Ogrzewany lokal',
        value: 'Ogrzewany lokal', 
    },
    {
        name: 'Nieogrzewany lokal lub piwnica',
        value: 'Nieogrzewany lokal lub piwnica',
    },
    {
        name: 'Świat zewnętrzny',
        value: 'Świat zewnętrzny',
    },
    {
        name: 'Grunt',
        value: 'Grunt'
    }
]