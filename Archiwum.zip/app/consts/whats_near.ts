export const whats_near: any = [
    {
        name: 'Ogrzewany lokal',
        value: 'Ogrzewany lokal', 
    },
    {
        name: 'Nieogrzewany lokal / korytarz / klatka schodowa',
        value: 'Nieogrzewany lokal / korytarz / klatka schodowa',
    },
    {
        name: 'Świat zewnętrzny',
        value: 'Świat zewnętrzny',
    },
]