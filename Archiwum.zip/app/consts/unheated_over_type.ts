export const unheated_over_type: any = [
    {
        name: 'Brak izolacji i odczuwalne są silne przeciągi',
        value: 'Brak izolacji i odczuwalne są silne przeciągi', 
    },
    {
        name: 'Brak izolacji, ale bez przeciągów, odczuwalna jest niska temperatura',
        value: 'Brak izolacji, ale bez przeciągów, odczuwalna jest niska temperatura'
    },
    {
        name: 'Ocieplenie dachu jest, ale słabej jakości',
        value: 'Ocieplenie dachu jest, ale słabej jakości'
    },
    {
        name: 'Dach jest dobrze ocieplony',
        value: 'Dach jest dobrze ocieplony'
    }
]