export const isolation_roof_materials: any = [
    {
        name: 'Celuloza',
        value: 'Celuloza', 
    },
    {
        name: 'Ekofiber',
        value: 'Ekofiber',
    },
    {
        name: 'Keramzyt',
        value: 'Keramzyt',
    },
    {
        name: 'Korek',
        value: 'Korek',
    },
    {
        name: 'Multipor',
        value: 'Multipor',
    },
    {
        name: 'Padzierz lniany',
        value: 'Padzierz lniany',
    },
    {
        name: 'PIR',
        value: 'PIR',
    },
    {
        name: 'PUR',
        value: 'PUR',
    },
    {
        name: 'Słoma',
        value: 'Słoma',
    },
    {
        name: 'Styropian',
        value: 'Styropian',
    },
    {
        name: 'Styropian grafitowy',
        value: 'Styropian grafitowy',
    },
    {
        name: 'Styropian twardy (XPS)',
        value: 'Styropian twardy (XPS)',
    },
    {
        name: 'Trociny drzewne',
        value: 'Trociny drzewne',
    },
    {
        name: 'Trzcina',
        value: 'Trzcina',
    },
    {
        name: 'Wełna drzewna',
        value: 'Wełna drzewna',
    },
    {
        name: 'Wełna mineralna',
        value: 'Wełna mineralna',
    },
    {
        name: 'Wełna mineralna granulowana',
        value: 'Wełna mineralna granulowana',
    },
    {
        name: 'Żużel',
        value: 'Żużel',
    },
]