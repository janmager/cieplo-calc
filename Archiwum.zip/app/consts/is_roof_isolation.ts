export const is_roof_isolation: any = [
    {
        name: 'Tak, jest izolacja'
    },
    {
        name: 'Nie, nie ma żadnej izolacji'
    },
]