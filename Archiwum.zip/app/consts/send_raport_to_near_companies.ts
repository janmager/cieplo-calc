export const send_raport_to_near_companies: any = [
    {
        name: 'Chcę wysłać zapytania do firm z okolicy'
    },
    {
        name: 'Nie, dziękuję.'
    },
]