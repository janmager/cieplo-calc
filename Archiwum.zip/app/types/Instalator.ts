export interface Instalator {
    name: string,
    phone: string,
    city: string
}