import React from 'react'

function page() {
  return (
    <div className='pt-32 pb-20 flex items-center justify-center gap-5 flex-col'>
        <h1 className='text-3xl font-bold tracking-tight'>Wystąpił błąd</h1>
        <p>....</p>
    </div>
  )
}

export default page