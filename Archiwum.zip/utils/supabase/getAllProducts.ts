'use server'

import prisma from '@/app/libs/db';

export const getAllProducts = async () => {
    try{
        const find: any = await prisma.product.findMany()
        if(find){
            return {
                response: true,
                data: JSON.parse(JSON.stringify(find))
            }
        }
        else{
            return {
                response: false
            }
        }
    }
    catch(error) {
        if (error instanceof Error){
            console.log("Error: ", error.stack)
            return {
                response: false
            }
        }
        else{
            return {
                response: false
            }
        }
    }
}